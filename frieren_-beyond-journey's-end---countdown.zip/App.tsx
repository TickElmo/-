
import React from 'react';
import CountdownTimer from './components/CountdownTimer';
import MagicParticles from './components/MagicParticles';
import QuoteSection from './components/QuoteSection';

const App: React.FC = () => {
  // Target date: Jan 18th, 18:30.
  // We assume the nearest Jan 18th.
  const getTargetDate = () => {
    const now = new Date();
    let year = now.getFullYear();
    const target = new Date(year, 0, 18, 18, 30, 0); // Month is 0-indexed (Jan = 0)
    
    // If today is past Jan 18 18:30 of current year, target next year
    if (now > target) {
      target.setFullYear(year + 1);
    }
    return target;
  };

  const targetDate = getTargetDate();

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center py-12 px-4 overflow-hidden">
      <MagicParticles />
      
      {/* Decorative Background Image Overlay */}
      <div 
        className="absolute inset-0 z-[-1] opacity-20 pointer-events-none bg-cover bg-center"
        style={{ backgroundImage: `url('https://picsum.photos/seed/frieren/1920/1080')` }}
      />
      <div className="absolute inset-0 bg-slate-900/60 z-[-1]" />

      {/* Main Content */}
      <main className="z-10 w-full max-w-6xl mx-auto text-center space-y-12">
        <header className="space-y-4">
          <div className="flex items-center justify-center gap-4 mb-4">
             <div className="h-px w-12 bg-blue-400/30" />
             <span className="text-blue-300 text-sm tracking-[0.3em] uppercase font-bold">Special Screening Event</span>
             <div className="h-px w-12 bg-blue-400/30" />
          </div>
          <h1 className="text-5xl md:text-8xl font-bold font-playfair text-white text-glow tracking-tight">
            葬送的芙莉蓮
          </h1>
          <p className="text-xl md:text-2xl text-blue-200/80 font-serif tracking-widest mt-4">
            — 面向「一月十八日」的旅程 —
          </p>
        </header>

        <section className="relative">
          <div className="absolute -inset-24 bg-blue-500/5 blur-[100px] rounded-full pointer-events-none" />
          <CountdownTimer targetDate={targetDate} />
          
          <div className="mt-8 space-y-2">
            <p className="text-blue-200/60 text-sm tracking-widest">
              上映時間：2026年1月18日 18:30
            </p>
            <p className="text-blue-400/40 text-xs italic">
              「在勇者欣梅爾逝世五十年後，旅程再次開始。」
            </p>
          </div>
        </section>

        <QuoteSection />

        <footer className="mt-20 pt-10 border-t border-white/5 w-full max-w-xl mx-auto flex flex-col items-center gap-6">
          <div className="flex gap-8 text-blue-300/40 text-sm uppercase tracking-widest font-bold">
            <a href="#" className="hover:text-blue-300 transition-colors">Story</a>
            <a href="#" className="hover:text-blue-300 transition-colors">Characters</a>
            <a href="#" className="hover:text-blue-300 transition-colors">Trailer</a>
          </div>
          <p className="text-blue-500/30 text-xs">
            © 2025 Frieren Journey Countdown. This is a fan-made celebration.
          </p>
        </footer>
      </main>

      {/* Decorative corners */}
      <div className="fixed top-0 left-0 w-32 h-32 border-t border-l border-blue-400/20 m-8 rounded-tl-3xl pointer-events-none" />
      <div className="fixed bottom-0 right-0 w-32 h-32 border-b border-r border-blue-400/20 m-8 rounded-br-3xl pointer-events-none" />
    </div>
  );
};

export default App;
